from flask import Flask, request, jsonify, render_template, session
import os
from dotenv import load_dotenv
import tempfile
from werkzeug.utils import secure_filename
import json
from typing import List, Dict
import threading
import time

# Document Processing Libraries
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_groq import ChatGroq
from langchain.memory import ChatMessageHistory
from langchain.chains import ConversationalRetrievalChain
from langchain.docstore.document import Document

# Web Search Libraries
from googlesearch import search
from newspaper import Article
import requests

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Add secret key for session management
load_dotenv()

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'docx'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Store processors in a dictionary with session IDs as keys
processors = {}
processor_lock = threading.Lock()


class DocumentProcessor:
    def __init__(self):
        self.GROQ_API_KEY = os.getenv('GROQ_API_KEY')
        self.embedding_model = HuggingFaceEmbeddings()
        self.conversation_chain = None
        self.vectorstore = None
        self.current_document = None
        self.chat_history = []
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )
        self.is_document_loaded = False
        self.last_access = time.time()

    def process_document(self, file_path: str) -> Dict:
        try:
            # Load document based on file extension
            ext = os.path.splitext(file_path)[1].lower()
            if ext == '.pdf':
                loader = PyPDFLoader(file_path)
            elif ext in ['.docx', '.doc']:
                loader = Docx2txtLoader(file_path)
            else:
                raise ValueError(f"Unsupported file type: {ext}")

            # Load and split documents
            documents = loader.load()
            self.current_document = documents

            # Reset chat history when new document is loaded
            self.chat_history = []

            # Process documents and create summary
            processed_data = self._process_documents(documents)

            # Setup conversation chain
            self._setup_conversation_chain(documents)

            # Set document loaded flag
            self.is_document_loaded = True
            self.last_access = time.time()

            return processed_data
        except Exception as e:
            print(f"Document Processing Error: {str(e)}")
            return {"error": str(e)}

    def _process_documents(self, documents: List[Document]) -> Dict:
        try:
            # Split documents into pages and chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=1000,
                chunk_overlap=100
            )

            # Process page by page
            page_summaries = {}
            full_text = []

            for i, doc in enumerate(documents):
                # Add page text to full text
                full_text.append(doc.page_content)

                # Create page summary
                page_summary = self._create_summary(doc.page_content)
                if page_summary:
                    page_summaries[str(i + 1)] = page_summary

            # Create full document summary
            full_summary = self._create_summary(" ".join(full_text)) if full_text else ""

            return {
                "full_summary": full_summary,
                "page_summaries": page_summaries
            }
        except Exception as e:
            print(f"Document Processing Error: {str(e)}")
            return {"error": str(e)}

    def _create_summary(self, text: str) -> str:
        try:
            # Simple extractive summary for now
            sentences = text.split('.')
            summary_sentences = sentences[:3]  # Take first 3 sentences
            summary = '. '.join(sentence.strip() for sentence in summary_sentences if sentence.strip())
            return summary + '.' if summary else ""
        except Exception as e:
            print(f"Summary Creation Error: {str(e)}")
            return ""

    def _setup_conversation_chain(self, documents: List[Document]):
        try:
            # Create vector store
            texts = self.text_splitter.split_documents(documents)
            self.vectorstore = Chroma.from_documents(
                documents=texts,
                embedding=self.embedding_model
            )

            # Initialize LLM
            llm = ChatGroq(
                model="llama-3.1-70b-versatile",
                temperature=0.3,
                max_tokens=1024,
                groq_api_key=self.GROQ_API_KEY
            )

            # Create conversation chain
            self.conversation_chain = ConversationalRetrievalChain.from_llm(
                llm=llm,
                retriever=self.vectorstore.as_retriever(search_kwargs={'k': 3}),
                return_source_documents=True,
                verbose=True
            )
        except Exception as e:
            print(f"Conversation Chain Setup Error: {str(e)}")
            self.conversation_chain = None

    def ask_question(self, question: str) -> Dict:
        try:
            if not self.is_document_loaded or not self.conversation_chain:
                return {"error": "Please upload a document first"}

            # Update last access time
            self.last_access = time.time()

            # Get response from conversation chain with chat history
            response = self.conversation_chain({
                "question": question,
                "chat_history": self.chat_history
            })

            # Update chat history
            self.chat_history.append((question, response['answer']))

            # Extract relevant page numbers and sources
            source_pages = set()
            sources = []
            if 'source_documents' in response:
                for doc in response['source_documents']:
                    if hasattr(doc, 'metadata') and 'page' in doc.metadata:
                        source_pages.add(doc.metadata['page'])
                    sources.append(doc.page_content[:200] + "...")  # Truncate long sources

            return {
                "answer": response['answer'],
                "sources": sources,
                "page_numbers": sorted(list(source_pages))
            }
        except Exception as e:
            print(f"Question Processing Error: {str(e)}")
            return {"error": str(e)}

    def web_search(self, query: str) -> List[Dict]:
        try:
            # Update last access time
            self.last_access = time.time()

            results = []
            for url in search(query, num_results=5):
                try:
                    article = Article(url)
                    article.download()
                    article.parse()

                    # Extract main content
                    summary = article.summary if article.summary else article.text[:200] + "..."

                    results.append({
                        "url": url,
                        "title": article.title,
                        "summary": summary
                    })
                except Exception as e:
                    print(f"Article Processing Error: {str(e)}")
                    continue

            return results
        except Exception as e:
            print(f"Web Search Error: {str(e)}")
            return []


def get_processor():
    if 'session_id' not in session:
        session['session_id'] = os.urandom(16).hex()

    session_id = session['session_id']

    with processor_lock:
        if session_id not in processors:
            processors[session_id] = DocumentProcessor()
        return processors[session_id]


def allowed_file(filename: str) -> bool:
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    if file and allowed_file(file.filename):
        try:
            processor = get_processor()
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            file.save(filepath)

            result = processor.process_document(filepath)
            return jsonify(result)
        except Exception as e:
            return jsonify({'error': str(e)})

    return jsonify({'error': 'Invalid file type'})


@app.route('/ask', methods=['POST'])
def ask_question():
    try:
        processor = get_processor()
        if not processor.is_document_loaded:
            return jsonify({'error': 'Please upload a document first'})

        data = request.get_json()
        question = data.get('question')
        if not question:
            return jsonify({'error': 'No question provided'})

        response = processor.ask_question(question)
        return jsonify(response)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/web-search', methods=['POST'])
def web_search():
    processor = get_processor()
    data = request.get_json()
    query = data.get('query')
    if not query:
        return jsonify({'error': 'No query provided'})

    results = processor.web_search(query)
    return jsonify(results)


# Clean up old processors periodically
def cleanup_old_processors():
    while True:
        time.sleep(3600)  # Run every hour
        with processor_lock:
            current_time = time.time()
            for session_id in list(processors.keys()):
                if current_time - processors[session_id].last_access > 3600:  # 1 hour timeout
                    del processors[session_id]


# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_old_processors, daemon=True)
cleanup_thread.start()

if __name__ == '__main__':
    app.run(debug=True)